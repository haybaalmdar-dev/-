export default function Reports() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-[#2c3e50] text-white py-6 px-8 shadow-md">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold">تقارير المبيعات</h1>
          <p className="mt-2 text-gray-200">تحليلات مفصلة لأداء المبيعات</p>
        </div>
      </header>

      <main className="container mx-auto py-8 px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
            <h2 className="text-xl font-semibold text-[#2c3e50] mb-4">تقرير يومي</h2>
            <p className="text-gray-600 mb-4">تحليلات مفصلة للمبيعات اليومية مع إحصائيات مفيدة.</p>
            <button className="bg-[#2c3e50] text-white px-4 py-2 rounded hover:bg-[#1a252f] transition-colors duration-300">
              عرض التقرير
            </button>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
            <h2 className="text-xl font-semibold text-[#2c3e50] mb-4">تقرير شهري</h2>
            <p className="text-gray-600 mb-4">نظرة شاملة على أداء المبيعات الشهرية مع مقارنات زمنية.</p>
            <button className="bg-[#2c3e50] text-white px-4 py-2 rounded hover:bg-[#1a252f] transition-colors duration-300">
              عرض التقرير
            </button>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
            <h2 className="text-xl font-semibold text-[#2c3e50] mb-4">تقرير سنوي</h2>
            <p className="text-gray-600 mb-4">تحليلات متعمقة لأداء المبيعات السنوي مع توقعات مستقبلية.</p>
            <button className="bg-[#2c3e50] text-white px-4 py-2 rounded hover:bg-[#1a252f] transition-colors duration-300">
              عرض التقرير
            </button>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-2xl font-bold text-[#2c3e50] mb-4">ميزات التقارير</h2>
          <ul className="list-disc list-inside text-gray-700 space-y-2">
            <li>تحليلات مفصلة للمبيعات حسب الفئات والمنتجات</li>
            <li>مقارنات زمنية بين الفترات المختلفة</li>
            <li>توقعات مبيعات مستقبلية مبنية على البيانات التاريخية</li>
            <li>تصدير التقارير إلى تنسيقات مختلفة (PDF, Excel)</li>
            <li>تخصيص التقارير حسب احتياجاتك</li>
          </ul>
        </div>
      </main>

      <footer className="bg-[#2c3e50] text-white py-6 mt-8">
        <div className="container mx-auto text-center">
          <p>© 2023 شركة تقارير المبيعات. جميع الحقوق محفوظة.</p>
        </div>
      </footer>
    </div>
  );
}