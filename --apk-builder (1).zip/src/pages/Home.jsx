export default function Dashboard() {
  return (
    <div className="flex h-screen bg-gray-100">
      <aside className="w-64 flex-shrink-0 bg-blue-700 p-4 text-white">
        <h2 className="mb-4 text-2xl font-bold">Dashboard</h2>
        <nav>
          <ul>
            <li className="mb-2">
              <a href="#" className="block p-2 hover:bg-blue-800">
                المبيعات
              </a>
            </li>
            <li className="mb-2">
              <a href="#" className="block p-2 hover:bg-blue-800">
                الأرباح
              </a>
            </li>
          </ul>
        </nav>
      </aside>
      <main className="flex-1 p-4">
        <header className="mb-4 flex justify-between">
          <h1 className="text-2xl font-bold">نظرة عامة</h1>
          <button className="bg-blue-700 hover:bg-blue-800 text-white font-bold py-2 px-4 rounded">
            إضافة منتج جديد
          </button>
        </header>
        <section className="mb-4">
          <h2 className="mb-2 text-lg font-bold">مبيعات هذا الشهر</h2>
          <p className="text-gray-600">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus nec arcu ac erat bibendum bibendum. Integer nec nulla malesuada, dictum dui id, ultricies nisi.
          </p>
          <div className="mt-4 flex justify-between">
            <div className="bg-white p-4 rounded shadow">
              <h3 className="mb-2 text-lg font-bold">إجمالي المبيعات</h3>
              <p className="text-2xl font-bold text-gray-900">10000$</p>
            </div>
            <div className="bg-white p-4 rounded shadow">
              <h3 className="mb-2 text-lg font-bold">إجمالي الأرباح</h3>
              <p className="text-2xl font-bold text-gray-900">5000$</p>
            </div>
          </div>
        </section>
        <section className="mb-4">
          <h2 className="mb-2 text-lg font-bold">أعلى المنتجات مبيعًا</h2>
          <ul>
            <li className="mb-2 flex justify-between">
              <span>منتج 1</span>
              <span>1000$</span>
            </li>
            <li className="mb-2 flex justify-between">
              <span>منتج 2</span>
              <span>800$</span>
            </li>
            <li className="mb-2 flex justify-between">
              <span>منتج 3</span>
              <span>600$</span>
            </li>
          </ul>
        </section>
      </main>
    </div>
  );
}