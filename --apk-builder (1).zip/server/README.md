# Backend

Generated stub for sales-management-system. Run with `node server/index.js` after wiring an Express server.